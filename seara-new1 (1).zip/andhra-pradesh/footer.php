<div id="hxb-enquiry-forms">
              <!-- Fixed Side Icons -->
            <div class="fixed-icons">
                <a href="tel:+919659965952" class="phone-icon"><i class="fas fa-phone-alt"></i></a>
                <a href="https://wa.link/d5d0cx" class="whatsapp-icon"><i class="fab fa-whatsapp"></i></a>
                <a href="#" class="mail-icon" id="mail-trigger"><i class="fas fa-envelope"></i></a>
            </div>
            
            <!-- WhatsApp Popup Form -->
            <div id="whatsapp-popup" class="popup-form">
                <div class="form-content">
                    <span class="close-btn" id="close-whatsapp">&times;</span>
                    <p class="h3 text-white text-center">Contact via WhatsApp</p>
                    <form id="whatsappForm" method="post">
                        <input type="text" id="whatsappName" name="whatsappName" placeholder="Name" required>
                        <input type="text" id="whatsappMobile" name="whatsappMobile" placeholder="Mobile" required>
                        <button type="submit" class="btn">Submit</button>
                    </form>
                </div>
            </div>
            
            <!-- Mail Popup Form -->
            <div id="mail-popup" class="popup-form">
                <div class="form-content">
                    <span class="close-btn" id="close-mail">&times;</span>
                    <p class="h3 text-white text-center">Contact via Email</p>
                    <form id="mailForm" method="post">
                        <input type="text" id="companyName" name="companyName" placeholder="Company Name" required>
                        <input type="text" id="name" name="name" placeholder="Name" required>
                        <input type="email" id="email" name="email" placeholder="Email" required>
                        <input type="text" id="mobile" name="mobile" placeholder="Mobile" required>
                        <input type="text" id="productService" name="productService" placeholder="Product/Services" required>
                        <textarea id="message" name="message" rows="2" placeholder="Message" required></textarea>
                        <button type="submit" class="btn">Send Message</button>
                    </form>
                </div>
            </div>
      </div>


<!-- Newsletter Start -->
<div class="container newsletter mt-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="row justify-content-center">
                <div class="col-lg-10 border rounded p-1">
                    <div class="border rounded text-center p-1">
                        <div class="bg-white rounded text-center p-5">
                            <!--<h4 class="mb-4">Subscribe Our <span class="text-primary text-uppercase">Newsletter</span></h4>
                            <div class="position-relative mx-auto" style="max-width: 400px;">
                                <input class="form-control w-100 py-3 ps-4 pe-5" type="text" placeholder="Enter your email">
                                <button type="button" class="btn btn-primary py-2 px-3 position-absolute top-0 end-0 mt-2 me-2">Submit</button>
                            </div>-->
                            <p><strong>Choose Saera Electric Auto Limited for innovative, sustainable, and reliable electric mobility solutions!</strong></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Newsletter Start -->
        
    <!-- Footer Start -->
        <div class="container-fluid bg-dark text-light footer wow fadeIn" data-wow-delay="0.1s">
            <div class="container pb-5">
                <div class="row g-5">
                    <div class="col-md-6 col-lg-4">
                        <div class="bg-primary rounded p-4">
                            <a href="../index.php" title="Logo"><h6 class="h4 text-white text-uppercase mb-3">Saera Electric Auto Limited</h4></a>
                            <p class="text-white mb-0">
								Explore our wide range of <strong>electric vehicles</strong> and join us in our mission to create a <strong>greener future</strong> with <strong>sustainable electric mobility</strong>. Together, we can drive the world toward a cleaner, more efficient tomorrow.
							</p>
                        </div>
                    </div>
                    <div class="col-md-6 col-lg-3">
                        <h6 class="section-title text-start text-primary text-uppercase mb-4">Contact</h6>
                        <p class="mb-2"><i class="fa fa-map-marker-alt me-3"></i>A-145B, RIICO Industrial Area, <span class="add">Bhiwadi, Alwar, Rajasthan -301019 India</span></p>
                       
                        <p class="mb-2"><i class="fa fa-phone-alt me-3"></i>+91-9659965952 </p>
                        <p class="mb-2"><a class="open-mail-popup text-white"><i class="fa fa-envelope me-3"></i>salesmarketing.golfcart@saeraindia.com</a></p>
                        <div class="d-flex pt-2">
                            <a class="btn btn-outline-light btn-social" title="Twitter" href="https://x.com/SaeraGolfCart"><i class="fab fa-twitter"></i></a>
                            <a class="btn btn-outline-light btn-social" title="Facebook" href="https://www.facebook.com/saeragolfcart"><i class="fab fa-facebook-f"></i></a>
                            <a class="btn btn-outline-light btn-social" title="Instagram" href="https://www.instagram.com/saeragolfcarts?utm_source=ig_web_button_share_sheet&igsh=ZDNlZDc0MzIxNw=="><i class="fab fa-instagram"></i></a>
                            <a class="btn btn-outline-light btn-social" href="https://www.linkedin.com/company/saera-electric-auto-pvt-ltd/" title="Linkedin"><i class="fab fa-linkedin-in"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-5 col-md-12">
                        <div class="row gy-5 g-4">
                            <div class="col-md-6">
                                <h6 class="section-title text-start text-primary text-uppercase mb-4">Quick Links</h6>
                                <a class="btn btn-link" href="../index.php" title="Home">Home</a>
                                <a class="btn btn-link" href="../company-profile.php" title="Company Profile">Company Profile</a>
                                <a class="btn btn-link" href="../contact.php" title="Contact Us">Contact Us</a>
                                <a class="btn btn-link" href="../site-map.php">Sitemap</a>
                                <a class="btn btn-link" href="../market-area.php">Market Area</a>
                            </div>
                            <div class="col-md-6">
                                <h6 class="section-title text-start text-primary text-uppercase mb-4">Products</h6>
                                <a class="btn btn-link" href="4-seater-golf-cart.php" title="4 Seater Golf Cart">4 Seater Golf Cart</a>
                                <a class="btn btn-link" href="8-seater-golf-cart.php" title="8 Seater Golf Cart">8 Seater Golf Cart</a>
                                <a class="btn btn-link" href="4-seater-utility-golf-cart.php" title="4 Seater Utility Golf Cart">4 Seater Utility Golf Cart</a>
                                <a class="btn btn-link" href="2-seater-utility-golf-cart.php" title="Mayuri Grand e-rikshaw">2 Seater Utility Golf Cart</a>
                                <a class="btn btn-link" href="4-seater-utility-golf-cart.php" title="Mayuri Loader">4 Seater Utility Golf Cart</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="copyright">
                    <div class="row">
                        <div class="col-md-6 text-center text-md-start mb-3 mb-md-0">
                            &copy; <a class="border-bottom" href="#">Saera Electric Auto Limited</a>, All Right Reserved. 
							
							<!--/*** This template is free as long as you keep the footer author’s credit link/attribution link/backlink. If you'd like to use the template without the footer author’s credit link/attribution link/backlink, you can purchase the Credit Removal License from "https://htmlcodex.com/credit-removal". Thank you for your support. ***/-->
							Designed By <a class="border-bottom" href="https://highxbrand.com" title="Highxbrand India Pvt. Ltd.">Highxbrand India Pvt. Ltd.</a>
                        </div>
                        <div class="col-md-6 text-center text-md-end">
                            <div class="footer-menu">
                                <a href="../privacy-policy.php">Privacy Policy</a>
                                <a href="../disclaimer.php">Disclaimer</a>
                                <a href="../terms-and-condition.php">Terms and Conditions</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Footer End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="../lib/wow/wow.min.js"></script>
    <script src="../lib/easing/easing.min.js"></script>
    <script src="../lib/waypoints/waypoints.min.js"></script>
    <script src="../lib/counterup/counterup.min.js"></script>
    <script src="../lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="../lib/tempusdominus/js/moment.min.js"></script>
    <script src="../lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="../lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>

    <!-- Template Javascript -->
    <script src="../js/main.js"></script>
 <script src="../Sjs/hxb-popup-forms.js"></script>
</body>

</html>