<?php $page_title = "Saera Electric Auto Limited, Mayuri Auto Manufacturer & Supplier in Assam";
  $description = "Mayuri Autos, produced by Saera Electric Auto Limited, are reasonably priced, environmentally friendly electric three-wheelers that are ideal for last-mile delivery and passenger transportation.";
  $keyword = "Mayuri Auto, Mayuri Auto manufacturer in Assam, Mayuri Auto manufacturer in Assam, Mayuri Auto exporter in Assam, Best manufacturer Mayuri Auto, Mayuri Auto supplier in Assam";
  include('header.php'); ?>
        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(../img/carousel-1.jpg);" title="Mayuri Auto Rickshaw Manufacturers in Assam" alt="Mayuri Auto Rickshaw Manufacturers in Assam">
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Mayuri Auto Rickshaw</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Mayuri Auto Rickshaw</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->

        <div class="container meta">
            

            <h2><strong> Mayuri Auto Rickshaw Manufacturers in Assam</strong></h2>
            <p>Saera Electric Auto Limited is recognized as a leading name among <strong>Mayuri Auto Rickshaw manufacturers in Assam</strong>, committed to delivering high-quality and efficient electric vehicles. The Mayuri Auto Rickshaw is designed to provide a reliable and comfortable mode of transportation, making it an excellent choice for urban commuting. With a focus on innovative design and performance, Saera ensures that each <strong>Mayuri Auto Rickshaw</strong> meets the highest standards of safety and durability. As a prominent <strong>Mayuri Auto Rickshaw manufacturer in Assam</strong>, Saera is dedicated to transforming public transport with eco-friendly solutions.</p>

            <h2><strong> Mayuri Auto Rickshaw Suppliers in Assam</strong></h2>
            <p>As a trusted <strong>Mayuri Auto Rickshaw supplier in Assam</strong>, Saera Electric Auto Limited offers a wide range of electric rickshaws tailored to meet diverse transportation needs. The <strong>Mayuri Auto Rickshaw</strong> is ideal for city travel, providing a sustainable alternative to traditional vehicles. Saera's commitment to customer service ensures timely deliveries and customized solutions, establishing the company as a leading <strong>Mayuri Auto Rickshaw supplier in Assam</strong> known for reliability and quality.</p>

            <h2><strong> Mayuri Auto Rickshaw Exporters in Assam</strong></h2>
            <p>Saera Electric Auto Limited has established itself as one of the top <strong>Mayuri Auto Rickshaw exporters in Assam</strong>, supplying premium electric rickshaws to various international markets. The company’s <strong>Mayuri Auto Rickshaws</strong> are built with the latest technology to ensure efficiency and low maintenance, making them a popular choice for global customers. With a focus on sustainability and high performance, Saera continues to expand its footprint as a reliable <strong>Mayuri Auto Rickshaw exporter in Assam</strong>, contributing to cleaner urban mobility worldwide.</p>


        </div>

        <div class="container">
            <div class="product col-lg-12">
                <div class="product-image col-lg-6">
                    <img src="../img/mayuri-auto.png" alt="Mayuri Auto Rickshaw Manufacturer in Assam" title="Mayuri Auto Rickshaw Manufacturer in Assam">
                </div>
                <div class="product-des col-lg-6">
                    <h2>Mayuri Auto Rickshaw</h2>
                    <p>The Mayuri Auto Rickshaw offers a practical and efficient electric commuting solution for urban settings. Its compact design allows for easy navigation through congested streets, while providing a comfortable ride for passengers. The Mayuri Auto is powered by an efficient electric motor, ensuring low operating costs and zero emissions, which are crucial for environmentally conscious users. This vehicle not only supports sustainable urban mobility but also offers drivers a reliable means of income. With its emphasis on passenger comfort and convenience, the Mayuri Auto Rickshaw is a smart choice for city transportation.</p>
                    
                </div>
            </div>
        </div>
<div class="container mt-4">
  
  <div class="d-flex flex-wrap align-items-center">
      <h4>Colours Available : </h4>
    <div style="width: 30px; height: 30px; background-color: red; margin-right: 5px; margin-left:5px;"></div>
    <div style="width: 30px; height: 30px; background-color: green; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: black; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: lightblue; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: blue; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: lightgray; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: gray; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: orange; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: yellow; margin-right: 5px;"></div>
  </div>
</div>
<br>
        <div class="spec-container">
            <h4 class="text-center mb-4">Golf Cart Technical Specifications</h4>
            
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Motor Power:</p>
                        <p class="spec-description">1500-Watt</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Suspension:</p>
                        <p class="spec-description">Telescopic (F), Leaf Spring (R)</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Brakes:</p>
                        <p class="spec-description">Drum Brakes (Front & Rear)</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">L x W x H:</p>
                        <p class="spec-description">2710 mm x 980 mm x 1800 mm</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Mileage:</p>
                        <p class="spec-description">Up to 120 Km / Charge*</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Bluetooth Music System:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Central Locking System:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Driver & Passenger Floormats:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">LED Headlights with DRL:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Lockable Driver Glovebox:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Passenger Cabin Lights:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Passenger Rain Curtains:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Passenger Grab Handles:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Reverse Buzzer System:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Steel Rims with Wheel Cover:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Stepney with Wheel Cover:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Windshield with Motorized Wiper:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Auto Style Full Dashboard:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Auto Styled Front Fascia:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Passenger Half Doors:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        </div>
<?php include('footer.php') ?>