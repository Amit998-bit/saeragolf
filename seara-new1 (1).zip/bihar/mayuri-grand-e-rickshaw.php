<?php $page_title = "Saera Electric Auto Limited, an Bihar manufacturer and supplier of Mayuri Grand E-Rickshaws";
  $description = "Mayuri Grand E-Rickshaws are reasonably priced, environmentally friendly electric vehicles for urban transportation and logistics, made by Saera Electric Auto Limited.";
  $keyword = "Mayuri Grand E-Rickshaw , Mayuri Grand E-Rickshaw manufacturer in Bihar, Mayuri Grand E-Rickshaw manufacturer in Bihar, Mayuri Grand E-Rickshaw exporter in Bihar, Best manufacturer Mayuri Grand E-Rickshaw, Mayuri Grand E-Rickshaw supplier in Bihar";
  include('header.php'); ?>


        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(../img/carousel-1.jpg);" title=" Mayuri Grand e-rikshaw Manufacturers in Bihar" alt=" Mayuri Grand e-rikshaw Manufacturers in Bihar">
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Mayuri Grand e-rikshaw</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Mayuri Grand e-rikshaw</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->

        <div class="container meta">
             

            <h2><strong> Mayuri Grand e-rikshaw Manufacturers in Bihar</strong> </h2>
            <p>When it comes to <strong>Mayuri Grand e-rikshaw manufacturers in Bihar</strong>, Saera Electric Auto Limited leads the way with its commitment to quality and innovation. The Mayuri Grand e-rikshaw is designed to offer a spacious and comfortable ride, making it ideal for urban transportation needs. Saera's focus on advanced technology ensures that each <strong>Mayuri Grand e-rikshaw</strong> delivers exceptional performance, reliability, and zero emissions. As one of the foremost <strong>Mayuri Grand e-rikshaw manufacturers in Bihar</strong>, Saera is dedicated to revolutionizing public transport with eco-friendly solutions.</p>

            <h2><strong> Mayuri Grand e-rikshaw Suppliers in Bihar</strong> </h2>
            <p>As a prominent <strong>Mayuri Grand e-rikshaw supplier in Bihar</strong>, Saera Electric Auto Limited provides a range of high-quality e-rikshaws that cater to various customer requirements. The <strong>Mayuri Grand e-rikshaw</strong> is perfect for short-distance travel, combining efficiency and sustainability. Saera’s commitment to customer service ensures that their clients receive timely deliveries and tailored solutions, making them a trusted <strong>Mayuri Grand e-rikshaw supplier in Bihar</strong> known for reliability and performance.</p>

            <h2><strong> Mayuri Grand e-rikshaw Exporters in Bihar</strong></h2>
            <p>Saera Electric Auto Limited has established itself as a leading <strong>Mayuri Grand e-rikshaw exporter in Bihar</strong>, supplying high-quality e-rikshaws to various international markets. The company’s <strong>Mayuri Grand e-rikshaws</strong> are built with modern technology to ensure durability and efficiency, making them a preferred choice for global customers. By emphasizing sustainability and quality, Saera continues to expand its reach as a reputable <strong>Mayuri Grand e-rikshaw exporter in Bihar</strong>, contributing to the global shift towards cleaner transportation solutions.</p>
 
        </div>

        <div class="container">
            <div class="product col-lg-12">
                <div class="product-image col-lg-6">
                    <img src="../img/mayuri-grand-e-rick.png" alt="Mayuri Grand e-rikshaw Manufacturer in Bihar" title="Mayuri Grand e-rikshaw Manufacturer in Bihar">
                </div>
                <div class="product-des col-lg-6">
                    <h2>Mayuri Grand e-rikshaw</h2>
                    <p>The Mayuri Grand e-rikshaw represents a modern solution for urban transportation needs. With spacious seating for multiple passengers, this electric vehicle is designed to provide a comfortable commuting experience in busy city environments. The Mayuri Grand is equipped with a powerful electric motor, ensuring efficient performance and low operational costs. Its eco-friendly design features zero emissions, aligning with global sustainability goals. The rickshaw is perfect for short-distance travel, offering a practical and affordable transportation option for both drivers and passengers. With its sleek design and emphasis on passenger comfort, the Mayuri Grand e-rikshaw is a forward-thinking choice for urban mobility.</p>
                </div>
            </div>
        </div>
<div class="container mt-4">
  
  <div class="d-flex flex-wrap align-items-center">
      <h4>Colours Available : </h4>
    <div style="width: 30px; height: 30px; background-color: red; margin-right: 5px; margin-left:5px;"></div>
    <div style="width: 30px; height: 30px; background-color: green; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: black; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: lightblue; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: blue; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: lightgray; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: gray; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: orange; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: yellow; margin-right: 5px;"></div>
  </div>
</div>
<br>
        <div class="spec-container">
            <h4 class="text-center mb-4"> Technical Specifications</h4>
            
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Motor Power:</p>
                        <p class="spec-description">1200-Watt</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Suspension:</p>
                        <p class="spec-description">Telescopic (F), Leaf Spring (R)</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Brakes:</p>
                        <p class="spec-description">Drum Brakes (Front & Rear)</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">L x W x H:</p>
                        <p class="spec-description">2690 mm x 980 mm x 1770 mm</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Mileage:</p>
                        <p class="spec-description">Up to 120 Km / Charge*</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Bluetooth Music System:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Central Locking System:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Driver & Passenger Curtains:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Stepney with Wheel Cover:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        </div>
 <?php include('footer.php') ?>