<?php include('header.php') ?>
 
        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-1.jpg);">
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Company Profile</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Company Profile</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->


        

        <div class="container">
            <div class="company-overview">
                <h2>Company Overview</h2>
                <p><strong>Saera Electric Auto Limited</strong> is a leading <strong>manufacturer</strong>, <strong>supplier</strong>, and <strong>exporter</strong> of electric vehicles, specializing in <strong>eco-friendly</strong> solutions that cater to modern transportation needs. Based in the industrial hub of <strong>Bhiwadi, Rajasthan</strong>, Saera Electric Auto is at the forefront of innovation in the <strong>electric vehicle (EV) industry</strong>, focusing on <strong>sustainable</strong> and cost-effective mobility solutions.</p>
                <p>With a commitment to providing <strong>high-quality electric vehicles</strong>, the company offers a diverse <strong>product range</strong> that addresses the needs of recreational spaces, urban logistics, and public transportation. <strong>Saera Electric Auto</strong> aims to contribute to a <strong>greener future</strong> by promoting <strong>clean, electric mobility</strong>.</p>
                
                <h3>Product Range</h3>
                <p><strong>Saera Electric Auto Limited</strong> offers a comprehensive range of electric vehicles designed to meet diverse transportation needs. Their product lineup includes Golf Carts, ideal for smooth mobility in recreational spaces such as parks, resorts, and golf courses...</p>
                
                <h3>Mission</h3>
                <p><strong>Saera Electric Auto Limited</strong> is dedicated to delivering <strong>cutting-edge electric mobility solutions</strong> that are sustainable, reliable, and cost-efficient...</p>
                
                <h3>Vision</h3>
                <p>The company envisions being a <strong>global leader in the electric vehicle industry</strong>, known for its <strong>innovation</strong>, quality, and commitment to sustainability...</p>
                
                <h3>Quality Assurance</h3>
                <p><strong>Saera Electric Auto Limited</strong> emphasizes stringent <strong>quality control measures</strong> throughout the production process to ensure the <strong>highest standards</strong> in all its vehicles...</p>
                
                <h3>Infrastructure and Technology</h3>
                <p>Equipped with <strong>state-of-the-art manufacturing facilities</strong>, <strong>Saera Electric Auto Limited</strong> uses advanced technology to design and produce its vehicles...</p>
                
                <h3>Sustainability Commitment</h3>
                <p>As a forward-thinking company, <strong>Saera Electric Auto Limited</strong> places <strong>sustainability</strong> at the core of its business practices...</p>
                
                <h3>Customer-Centric Approach</h3>
                <p>At <strong>Saera Electric Auto Limited</strong>, <strong>customer satisfaction</strong> is a top priority. The company offers tailored solutions to meet the specific requirements of its clients...</p>
                
                <h3>Export Markets</h3>
                <p><strong>Saera Electric Auto Limited</strong> exports its products to various <strong>international markets</strong>, with a focus on maintaining the same high quality and reliability that it is known for domestically...</p>
            </div>
        </div>


 <?php include('footer.php') ?>