<?php include('header.php') ?>


        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-1.jpg);">
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Contact us</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Contact us</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->


        <!-- Contact Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="section-title text-center text-primary text-uppercase">Contact Us</h6>
                    <h1 class="mb-5"><span class="text-primary text-uppercase">Contact</span> For Any Query</h1>
                </div>
                <div class="row g-4 mb-5">
                    <div class="col-sm-6">
                        <div class="row gy-4">
                            <div class="col-12">
                                <h6 class="section-title text-start text-primary text-uppercase">Address</h6>
                                <p><i class="fa fa-map-marker-alt text-primary me-2"></i>A-145B, RIICO Industrial Area, Bhiwadi, Alwar, Rajasthan -301019 India</p>
                            </div>
                            <div class="col-12">
                                <h6 class="section-title text-start text-primary text-uppercase">E-mail</h6>
                                <p class="open-mail-popup"><i class="fa fa-envelope-open text-primary me-2"></i>salesmarketing.golfcart@saeraindia.com</p>
                            </div>
                            <div class="col-12">
                                <h6 class="section-title text-start text-primary text-uppercase">Phone</h6>
                                
                                <p><i class="fa fa-phone-alt text-primary me-2"></i>+91-9659965952</p>
                            </div>
                        </div>
                        
                        </div>
                        <div class="col-sm-6">
                       <form id="contactPageForm" method="post" 
    style="max-width: 600px; margin: 0 auto; padding: 20px; background-color: #ffffff; border: 1px solid #e0e0e0; border-radius: 10px; box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1); font-family: Arial, sans-serif; font-size: 14px;">
    <div class="row" style="display: flex; flex-wrap: wrap; gap: 20px;">
        <div class="col-sm-6" style="flex: 1; min-width: calc(50% - 10px);">
            <label for="companyName" style="display: block; margin-bottom: 5px; font-weight: 600; color: #333;">Company Name</label>
            <input type="text" id="companyName" name="companyName" placeholder="Enter your company name" required 
                style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; outline: none; transition: border-color 0.3s;">
        </div>
        <div class="col-sm-6" style="flex: 1; min-width: calc(50% - 10px);">
            <label for="name" style="display: block; margin-bottom: 5px; font-weight: 600; color: #333;">Name</label>
            <input type="text" id="name" name="name" placeholder="Enter your name" required 
                style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; outline: none; transition: border-color 0.3s;">
        </div>
        <div class="col-sm-6" style="flex: 1; min-width: calc(50% - 10px);">
            <label for="email" style="display: block; margin-bottom: 5px; font-weight: 600; color: #333;">Email</label>
            <input type="email" id="email" name="email" placeholder="Enter your email" required 
                style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; outline: none; transition: border-color 0.3s;">
        </div>
        <div class="col-sm-6" style="flex: 1; min-width: calc(50% - 10px);">
            <label for="mobile" style="display: block; margin-bottom: 5px; font-weight: 600; color: #333;">Mobile</label>
            <input type="text" id="mobile" name="mobile" placeholder="Enter your mobile number" required 
                style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; outline: none; transition: border-color 0.3s;">
        </div>
        <div class="col-sm-6" style="flex: 1; min-width: calc(50% - 10px);">
            <label for="productService" style="display: block; margin-bottom: 5px; font-weight: 600; color: #333;">Product/Services</label>
            <input type="text" id="productService" name="productService" placeholder="Enter product/services" required 
                style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; outline: none; transition: border-color 0.3s;">
        </div>
        <div class="col-sm-12" style="flex: 1; width: 100%;">
            <label for="message" style="display: block; margin-bottom: 5px; font-weight: 600; color: #333;">Message</label>
            <textarea id="message" name="message" placeholder="Write your message" required 
                style="width: 100%; padding: 10px; border: 1px solid #ccc; border-radius: 5px; outline: none; transition: border-color 0.3s; height: 40px;"></textarea>
        </div>
    </div>
    <button type="submit" class="btn btn-primary mt-2" 
        style="margin-top: 20px; padding: 12px 20px; border-radius: 5px; font-size: 16px; cursor: pointer; width: 100%; transition: background-color 0.3s;">
        Send Message
    </button>
</form>


                        </div>
                    </div
                   

                    <div class="col-md-12 wow fadeIn" data-wow-delay="0.1s">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d25455.892485411423!2d76.82090499369059!3d28.200943553813314!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390d379f9622931b%3A0x62f683c89f2a464a!2sRIICO%20Industrial%20Area%2C%20Bhiwadi%2C%20Rajasthan%20301019!5e1!3m2!1sen!2sin!4v1730271531853!5m2!1sen!2sin" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                    </div>
                </div>
            </div>
        </div>
        <style>
            textarea {
                height:40px;
                margin-top:5px;
                width:auto;
            }
        </style>
        <!-- Contact End -->
<?php include('footer.php') ?>