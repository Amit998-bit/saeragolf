<?php include('header.php') ?>

        <!-- Carousel Start -->
        <div class="container-fluid p-0 mb-5">
            <div id="header-carousel" class="carousel slide" data-bs-ride="carousel">
                <div class="carousel-inner">
                    <div class="carousel-item">
                        <img class="w-100" src="img/bn-1.png" alt="Manufacturer of 4 Seater Golf Cart" title="Manufacturer of 4 Seater Golf Cart">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <div class="p-3" style="max-width: 700px;">
                                <p class="h6 section-title text-white text-uppercase mb-3 animated slideInDown">Leading Manufacturer of</p>
                                <h1 class="display-3 text-white mb-4 animated slideInDown">4 Seater Golf Cart</h1>
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item active">
                        <img class="w-100" src="img/bn-2.png" alt="Manufacturer of 8 Seater Golf Cart" title="Manufacturer of 8 Seater Golf Cart">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <div class="p-3" style="max-width: 700px;">
                                <p class="h6 section-title text-white text-uppercase mb-3 animated slideInDown">Leading Manufacturer of</p>
                                <h2 class="h1 display-3 text-white mb-4 animated slideInDown">8 Seater Golf Cart</h2>
                                
                            </div>
                        </div>
                    </div>
                    <div class="carousel-item">
                        <img class="w-100" src="img/bn-3.png" alt="Manufacturer of 4 Seater Utility Golf Cart" title="Manufacturer of 4 Seater Utility Golf Cart">
                        <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">
                            <div class="p-3" style="max-width: 700px;">
                                <p class="h6 section-title text-white text-uppercase mb-3 animated slideInDown">Leading Manufacturer of</p>
                                <h2 class="h1 display-3 text-white mb-4 animated slideInDown">4 Seater Utility Golf Cart</h2>
                                
                            </div>
                        </div>
                    </div>
                    <!--<div class="carousel-item">-->
                    <!--    <img class="w-100" src="img/bn-4.png" alt="Manufacturer of Mayuri Grand E-rikshaw" title="Manufacturer of Mayuri Grand E-rikshaw">-->
                    <!--    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">-->
                    <!--        <div class="p-3" style="max-width: 700px;">-->
                    <!--            <p class="h6 section-title text-white text-uppercase mb-3 animated slideInDown">Leading Manufacturer of</p>-->
                    <!--            <h2 class="h1 display-3 text-white mb-4 animated slideInDown">Mayuri Grand E-rikshaw</h2>-->
                                
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                    <!--<div class="carousel-item">-->
                    <!--    <img class="w-100" src="img/bn-5.png" alt="Manufacturer of Mayuri Grand E-cart" title="Manufacturer of Mayuri Grand E-cart">-->
                    <!--    <div class="carousel-caption d-flex flex-column align-items-center justify-content-center">-->
                    <!--        <div class="p-3" style="max-width: 700px;">-->
                    <!--            <p class="h6 section-title text-white text-uppercase mb-3 animated slideInDown">Mayuri Loader</p>-->
                    <!--            <h2 class="h1 display-3 text-white mb-4 animated slideInDown">E-cart</h2>-->
                                
                    <!--        </div>-->
                    <!--    </div>-->
                    <!--</div>-->
                </div>
                <button class="carousel-control-prev" type="button" data-bs-target="#header-carousel" data-bs-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Previous</span>
                </button>
                <button class="carousel-control-next" type="button" data-bs-target="#header-carousel" data-bs-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="visually-hidden">Next</span>
                </button>
            </div>
        </div>
        <!-- Carousel End -->


        <!-- Booking Start 
        <div class="container-fluid booking pb-5 wow fadeIn" data-wow-delay="0.1s">
            <div class="container">
                <div class="bg-white shadow" style="padding: 35px;">
                    <div class="row g-2">
                        <div class="col-md-10">
                            <div class="row g-2">
                                <div class="col-md-3">
                                    <div class="date" id="date1" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input"
                                            placeholder="Check in" data-target="#date1" data-toggle="datetimepicker" />
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <div class="date" id="date2" data-target-input="nearest">
                                        <input type="text" class="form-control datetimepicker-input" placeholder="Check out" data-target="#date2" data-toggle="datetimepicker"/>
                                    </div>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-select">
                                        <option selected>Adult</option>
                                        <option value="1">Adult 1</option>
                                        <option value="2">Adult 2</option>
                                        <option value="3">Adult 3</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select class="form-select">
                                        <option selected>Child</option>
                                        <option value="1">Child 1</option>
                                        <option value="2">Child 2</option>
                                        <option value="3">Child 3</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-2">
                            <button class="btn btn-primary w-100">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
        </div>
         Booking End -->


        <!-- About Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6">
                        <p class="h6 section-title text-start text-primary text-uppercase">About Us</h6>
                        <h3 class="h1 mb-4">Welcome to <span class="text-primary text-uppercase"><strong>Saera Electric Auto Limited</strong></span></h1>
                        <p class="mb-4"> A leading <strong>manufacturer</strong>, <strong>supplier</strong>, and <strong>exporter</strong> of premium electric vehicles. Based in the industrial hub of <strong>Bhiwadi, Rajasthan</strong>, we specialize in providing innovative, eco-friendly solutions that cater to modern transportation needs. Our product range includes <strong>Golf Carts</strong>, <strong>Ecarts</strong>, <strong>Golf Carts with Loaders</strong>, <strong>Ecarts with Loaders</strong>, and <strong>e-rikshawshaws</strong>, all designed for both utility and sustainability.
                        </p>
                        <p class="mb-4">At <strong>Saera Electric Auto</strong>, we are committed to delivering the highest quality electric vehicles, with a focus on <strong>reliability</strong>, <strong>safety</strong>, and <strong>performance</strong>. Our products are engineered to provide cost-effective, environmentally friendly transportation solutions, reducing carbon footprints and promoting <strong>sustainable mobility</strong>.
                        </p>
                        <a class="btn btn-primary py-3 px-5 mt-2" href="company-profile.php" title="About Us">Explore More</a>
                    </div>
                    <div class="col-lg-6">
                        <div class="row g-3">
                             <img class="img-fluid rounded w-100 wow zoomIn" data-wow-delay="0.3s" src="img/home-abt-2.png" alt="Manufacturer of Mayuri Loader E-rikshaw" title="Manufacturer of Mayuri Loader E-rikshaw">
                            <!--<div class="col-6 text-end">-->
                            <!--    <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.1s" src="img/home-abt.png" style="margin-top: 25%;" alt="Manufacturer of Mayuri Grand E-rikshaw" title="Manufacturer of Mayuri Grand E-rikshaw">-->
                            <!--</div>-->
                            <!--<div class="col-6 text-start">-->
                            <!--    <img class="img-fluid rounded w-100 wow zoomIn" data-wow-delay="0.3s" src="img/home-abt-2.png" alt="Manufacturer of Mayuri Loader E-rikshaw" title="Manufacturer of Mayuri Loader E-rikshaw">-->
                            <!--</div>-->
                            <!--<div class="col-6 text-end">-->
                            <!--    <img class="img-fluid rounded w-50 wow zoomIn" data-wow-delay="0.5s" src="img/home-abt-3.png" alt="Manufacturer of 4 Seater Golf Cart" title="Manufacturer of 4 Seater Golf Cart">-->
                            <!--</div>-->
                            <!--<div class="col-6 text-start">-->
                            <!--    <img class="img-fluid rounded w-75 wow zoomIn" data-wow-delay="0.7s" src="img/home-abt-4.png" alt="Manufacturer of 4 Seater Utility Golf Cart" title="Manufacturer of 4 Seater Utility Golf Cart">-->
                            <!--</div>-->
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- About End -->


        <!-- Room Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <p class="h6 section-title text-center text-primary text-uppercase">Our Products</h6>
                    <h4 class="h1 mb-5">Explore Our <span class="text-primary text-uppercase">Products</span></h1>
                </div>
                <div class="row g-4">
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="room-item shadow rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/2-seater-golf-cart-1.png" alt="Manufacturer of 2 Seater Golf Cart" title="Manufacturer of 2 Seater Golf Cart">
                                
                            </div>
                            <div class="p-4 mt-2">
                                <div class="d-flex justify-content-between mb-3">
                                    <h5 class="mb-0">2 Seater Golf Cart</h5>
                                    
                                </div>
                                
                                <p class="text-body mb-3">The 2 Seater Golf Cart from Saera Electric is an essential vehicle for those who appreciate comfort and convenience in recreational spaces.</p>
                                <div class="d-flex justify-content-between">
                                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="2-seater-golf-cart.php" title="2 Seater Golf Cart">View Detail</a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="room-item shadow rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/4-seater-golf-cart-1.png" alt="Manufacturer of 4 Seater Golf Cart" title="Manufacturer of 4 Seater Golf Cart">
                                
                            </div>
                            <div class="p-4 mt-2">
                                <div class="d-flex justify-content-between mb-3">
                                    <h5 class="mb-0">4 Seater Golf Cart</h5>
                                    
                                </div>
                                
                                <p class="text-body mb-3">Enhance your outdoor experience with the 4 Seater Golf Cart by Saera Electric, designed for families and groups seeking a reliable mode of transport in leisure areas.</p>
                                <div class="d-flex justify-content-between">
                                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="4-seater-golf-cart.php" title="4 Seater Golf Cart">View Detail</a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="room-item shadow rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/6-seater-golf-cart-1 (1).png" alt="Manufacturer of 6 Seater Golf Cart" title="Manufacturer of6 Seater Golf Cart">
                                
                            </div>
                            <div class="p-4 mt-2">
                                <div class="d-flex justify-content-between mb-3">
                                    <h5 class="mb-0">6 Seater Golf Cart</h5>
                                    
                                </div>
                                
                                <p class="text-body mb-3">For larger gatherings, the 6 Seater Golf Cart by Saera Electric is your go-to solution. </p>
                                <div class="d-flex justify-content-between">
                                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="6-seater-golf-cart.php" title="6 Seater Golf Cart">View Detail</a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <div class="row g-4">
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="room-item shadow rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/8-seater-golf-cart-1.png" alt="Manufacturer of 8 Seater Golf Cart" title="Manufacturer of 8 Seater Golf Cart">
                                
                            </div>
                            <div class="p-4 mt-2">
                                <div class="d-flex justify-content-between mb-3">
                                    <h5 class="mb-0">8 Seater Golf Cart</h5>
                                    
                                </div>
                                
                                <p class="text-body mb-3">The 8 Seater Golf Cart offers unparalleled space and comfort, making it an excellent choice for larger groups needing efficient transport in recreational areas.</p>
                                <div class="d-flex justify-content-between">
                                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="8-seater-golf-cart.php" title="8 Seater Golf Cart">View Detail</a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="room-item shadow rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/2-seater-utility-golf-cart.png" alt="Manufacturer of 2 Seater Utitlity Golf Cart" title="Manufacturer of 2 Seater Utility Golf Cart">
                                
                            </div>
                            <div class="p-4 mt-2">
                                <div class="d-flex justify-content-between mb-3">
                                    <h5 class="mb-0">2 Seater Utility Golf Cart</h5>
                                    
                                </div>
                                
                                <p class="text-body mb-3">The 2 Seater Utility Golf Cart from Saera Electric is designed for versatility, combining the benefits of a golf cart with utility features for operational tasks.</p>
                                <div class="d-flex justify-content-between">
                                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="2-seater-utility-golf-cart.php" title="2 Seater Utility Golf Cart">View Detail</a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="room-item shadow rounded overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/4-seater-utility-golf-cart.png" alt="Manufacturer of 4 Seater Utility Golf Cart" title="Manufacturer of 4 Seater Utility Golf Cart">
                                
                            </div>
                            <div class="p-4 mt-2">
                                <div class="d-flex justify-content-between mb-3">
                                    <h5 class="mb-0">4 Seater Utility Golf Cart</h5>
                                    
                                </div>
                                
                                <p class="text-body mb-3">The 4 Seater Utility Golf Cart is the ideal choice for businesses and organizations that require both passenger transport and utility capabilities.</p>
                                <div class="d-flex justify-content-between">
                                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="4-seater-utility-golf-cart.php" title="4 Seater Utility Golf Cart">View Detail</a>
                                    
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <br>
                <!--<div class="row g-4">-->
                <!--    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">-->
                <!--        <div class="room-item shadow rounded overflow-hidden">-->
                <!--            <div class="position-relative">-->
                <!--                <img class="img-fluid" src="img/rikshaw.png" alt="Manufacturer of Mayuri Grand e-rikshaw" title="Manufacturer of Mayuri Grand e-rikshaw">-->
                                
                <!--            </div>-->
                <!--            <div class="p-4 mt-2">-->
                <!--                <div class="d-flex justify-content-between mb-3">-->
                <!--                    <h5 class="mb-0">Mayuri Grand E-rikshaw</h5>-->
                                    
                <!--                </div>-->
                                
                <!--                <p class="text-body mb-3">The Mayuri Grand e-rikshawshaw represents a modern solution for urban transportation needs.</p>-->
                <!--                <div class="d-flex justify-content-between">-->
                <!--                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="mayuri-grand-e-rikshaw.php" title="Mayuri Grand e-rikshaw">View Detail</a>-->
                                    
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">-->
                <!--        <div class="room-item shadow rounded overflow-hidden">-->
                <!--            <div class="position-relative">-->
                <!--                <img class="img-fluid" src="img/loader.png" alt="Manufacturer of Mayuri Loader e-rikshaw" title="Manufacturer of Mayuri Loader e-rikshaw">-->
                                
                <!--            </div>-->
                <!--            <div class="p-4 mt-2">-->
                <!--                <div class="d-flex justify-content-between mb-3">-->
                <!--                    <h5 class="mb-0">Mayuri Loader</h5>-->
                                    
                <!--                </div>-->
                                
                <!--                <p class="text-body mb-3">The Mayuri Loader e-rikshawshaw is engineered specifically for efficient goods transportation within urban areas.</p>-->
                <!--                <div class="d-flex justify-content-between">-->
                <!--                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="mayuri-loader-e-rikshaw.php" title="Mayuri Loader e-rikshaw">View Detail</a>-->
                                    
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">-->
                <!--        <div class="room-item shadow rounded overflow-hidden">-->
                <!--            <div class="position-relative">-->
                <!--                <img class="img-fluid" src="img/auto.png" alt="Manufacturer of Mayuri Auto" title="Manufacturer of Mayuri Auto">-->
                                
                <!--            </div>-->
                <!--            <div class="p-4 mt-2">-->
                <!--                <div class="d-flex justify-content-between mb-3">-->
                <!--                    <h5 class="mb-0">Mayuri Auto</h5>-->
                                    
                <!--                </div>-->
                                
                <!--                <p class="text-body mb-3">The Mayuri Auto Rickshaw offers a practical and efficient electric commuting solution for urban settings.</p>-->
                <!--                <div class="d-flex justify-content-between">-->
                <!--                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="mayuri-auto-rickshaw.php" title="Mayuri Auto">View Detail</a>-->
                                    
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
                <br>
                <!--<div class="row g-4">-->
                <!--    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">-->
                <!--        <div class="room-item shadow rounded overflow-hidden">-->
                <!--            <div class="position-relative">-->
                <!--                <img class="img-fluid" src="img/mayuri-delivery-van.png" alt="Manufacturer of Mayuri Delivery Van" title="Manufacturer of Mayuri Delivery Van">-->
                                
                <!--            </div>-->
                <!--            <div class="p-4 mt-2">-->
                <!--                <div class="d-flex justify-content-between mb-3">-->
                <!--                    <h5 class="mb-0">Mayuri Delivery Van</h5>-->
                                    
                <!--                </div>-->
                                
                <!--                <p class="text-body mb-3">The Mayuri Delivery Van is tailored for businesses seeking an eco-friendly logistics solution.</p>-->
                <!--                <div class="d-flex justify-content-between">-->
                <!--                    <a class="btn btn-sm btn-primary rounded py-2 px-4" href="mayuri-delivery-van.php" title="Mayuri Delivery Van">View Detail</a>-->
                                    
                <!--                </div>-->
                <!--            </div>-->
                <!--        </div>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
        <!-- Room End -->


        <!-- Video Start -->
        <div class="container-xxl py-5 px-0 wow zoomIn" data-wow-delay="0.1s">
            <div class="row g-0">
                <div class="col-md-6 bg-dark d-flex align-items-center">
                    <div class="p-5">
                        <p class="h6 section-title text-start text-white text-uppercase mb-3">Luxury Styling</p>
                        <h5 class="h1 text-white mb-4">Discover A Brand Luxurious Golf Cart</h5>
                        <p class="text-white mb-4">Discover a New Level of Luxury with Our Premium Golf Carts Step into a world of sophistication and innovation with our luxurious golf carts, crafted for those who seek the finest experience on the green.</p>
                        <a class="open-mail-popup btn btn-primary py-md-3 px-md-5 me-3" title="Contact Us">Get Enquiry</a>
                        <a href="4-seater-golf-cart.php" class="btn btn-light py-md-3 px-md-5">Know More</a>
                    </div>
                </div>
                <div class="col-md-6">
                    <img src="img/form-cart.png" alt="Mayuri Delivery Van" title="Mayuri Delivery Van" width="100%">
                </div>
            </div>
        </div>
        <!-- Video Start -->

<div class="container mt-4">
       <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h5 class="h6 section-title text-center text-primary text-uppercase">Golf Cart</h5>
                    <h5 class="h1 mb-5">Industry <span class="text-primary text-uppercase">Applications</span></h5>
                </div>
  <div class="row">
    <!-- SPORTS Column -->
    <div class="col-12 col-md-4 col-lg-2 category-column">
      <div class="category-card">SPORTS</div>
      <div class="item-card">Golf</div>
      <div class="item-card">Field Sports</div>
    </div>

    <!-- HOSPITALITY Column -->
    <div class="col-12 col-md-4 col-lg-2 category-column">
      <div class="category-card">HOSPITALITY</div>
      <div class="item-card">Hotel Chains</div>
      <div class="item-card">Independent Resorts</div>
      <div class="item-card">Business Hotels</div>
    </div>

    <!-- COMMERCIAL Column -->
    <div class="col-12 col-md-4 col-lg-2 category-column">
      <div class="category-card">COMMERCIAL</div>
      <div class="item-card">Malls</div>
      <div class="item-card">Airports</div>
      <div class="item-card">Logistic Hubs</div>
    </div>

    <!-- RESIDENTIAL Column -->
    <div class="col-12 col-md-4 col-lg-2 category-column">
      <div class="category-card">RESIDENTIAL</div>
      <div class="item-card">Apartments</div>
      <div class="item-card">Smart Cities</div>
    </div>

    <!-- CORPORATE Column -->
    <div class="col-12 col-md-4 col-lg-2 category-column">
      <div class="category-card">CORPORATE</div>
      <div class="item-card">Office Complexes</div>
      <div class="item-card">Corporate Hubs</div>
      <div class="item-card">Universities</div>
    </div>

    <!-- GOVERNMENT Column -->
    <div class="col-12 col-md-4 col-lg-2 category-column">
      <div class="category-card">GOVERNMENT</div>
      <div class="item-card">Tourism</div>
      <div class="item-card">Railways</div>
      <div class="item-card">Armed Forces</div>
      <div class="item-card">Govt. Complexes</div>
    </div>
  </div>
</div>
        <!-- Service Start -->
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h5 class="h6 section-title text-center text-primary text-uppercase">Why</h5>
                    <h5 class="h1 mb-5">Choose <span class="text-primary text-uppercase">Us</span></h5>
                </div>
               
<div class="row g-4">
    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
        <a class="service-item rounded" href="">
            <div class="service-icon bg-transparent border rounded p-1">
                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
                    <i class="fas fa-bolt fa-2x text-primary"></i>
                </div>
            </div>
            <h5 class="mb-3">India's Biggest E-Rickshaw Plants</h5>
            <p class="text-body mb-0">Saera Electric Auto Limited boasts India's largest e-rickshaw production facilities, spread across strategic locations.</p>
        </a>
    </div>
    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="1.0s">
        <a class="service-item rounded" href="">
            <div class="service-icon bg-transparent border rounded p-1">
                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
                    <i class="fas fa-check-circle fa-2x text-primary"></i>
                </div>
            </div>
            <h5 class="mb-3">Comprehensive Quality Inspections</h5>
            <p class="text-body mb-0">We follow over 140 checkpoints and conduct triple Pre-Dispatch Inspections to ensure each vehicle meets our high standards.</p>
        </a>
    </div>
    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
        <a class="service-item rounded" href="">
            <div class="service-icon bg-transparent border rounded p-1">
                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
                    <i class="fas fa-cogs fa-2x text-primary"></i>
                </div>
            </div>
            <h5 class="mb-3">State-of-the-Art Assembly Line</h5>
            <p class="text-body mb-0">We operate the most advanced electric vehicle assembly line in India, with full production capabilities from start to finish.</p>
        </a>
    </div>
    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.4s">
        <a class="service-item rounded" href="">
            <div class="service-icon bg-transparent border rounded p-1">
                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
                    <i class="fas fa-spray-can fa-2x text-primary"></i>
                </div>
            </div>
            <h5 class="mb-3">High-Quality Paint and Coating</h5>
            <p class="text-body mb-0">Our facility includes a best-in-class paint and coating shop, ensuring a premium finish on every vehicle.</p>
        </a>
    </div>
    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
        <a class="service-item rounded" href="">
            <div class="service-icon bg-transparent border rounded p-1">
                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
                    <i class="fas fa-vial fa-2x text-primary"></i>
                </div>
            </div>
            <h5 class="mb-3">11-Tank Phosphating Process</h5>
            <p class="text-body mb-0">We use an 11-tank phosphating process that ensures a vehicle body life of over 10 years.</p>
        </a>
    </div>
    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.6s">
        <a class="service-item rounded" href="">
            <div class="service-icon bg-transparent border rounded p-1">
                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
                    <i class="fas fa-hammer fa-2x text-primary"></i>
                </div>
            </div>
            <h5 class="mb-3">Hydraulic and Machine Press</h5>
            <p class="text-body mb-0">Our facility includes hydraulic presses up to 700 tons and machine presses up to 400 tons for robust vehicle construction.</p>
        </a>
    </div>
    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
        <a class="service-item rounded" href="">
            <div class="service-icon bg-transparent border rounded p-1">
                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
                    <i class="fas fa-clipboard-check fa-2x text-primary"></i>
                </div>
            </div>
            <h5 class="mb-3">5S Production Standards</h5>
            <p class="text-body mb-0">We strictly follow 5S production standards, ensuring an organized, clean, and efficient workplace.</p>
        </a>
    </div>
    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.8s">
        <a class="service-item rounded" href="">
            <div class="service-icon bg-transparent border rounded p-1">
                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
                    <i class="fas fa-robot fa-2x text-primary"></i>
                </div>
            </div>
            <h5 class="mb-3">Robotic Welding & Polishing</h5>
            <p class="text-body mb-0">Our robotic systems for plasma cutting, welding, and polishing enhance precision and consistency in production.</p>
        </a>
    </div>
    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.9s">
        <a class="service-item rounded" href="">
            <div class="service-icon bg-transparent border rounded p-1">
                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">
                    <i class="fas fa-shipping-fast fa-2x text-primary"></i>
                </div>
            </div>
            <h5 class="mb-3">High Daily Production Capacity</h5>
            <p class="text-body mb-0">We can deliver over 300 vehicles per day, supporting large-scale demands and prompt service.</p>
        </a>
    </div>
   
</div>

                <!--<div class="row g-4">-->
                <!--    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.1s">-->
                <!--        <a class="service-item rounded" href="">-->
                <!--            <div class="service-icon bg-transparent border rounded p-1">-->
                <!--                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">-->
                <!--                    <i class="bi bi-lightning-charge fa-2x text-primary"></i>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--            <h5 class="mb-3">Innovative Electric Vehicles:</h5>-->
                <!--            <p class="text-body mb-0">At Saera Electric Auto Limited, we offer a wide range of cutting-edge electric vehicles designed to meet diverse transportation needs, including Golf Carts, Ecarts, and e-rikshawshaws. Our vehicles are engineered to combine efficiency, performance, and eco-friendliness.</p>-->
                <!--        </a>-->
                <!--    </div>-->
                <!--    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.2s">-->
                <!--        <a class="service-item rounded" href="">-->
                <!--            <div class="service-icon bg-transparent border rounded p-1">-->
                <!--                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">-->
                <!--                    <i class="bi bi-star fa-2x text-primary"></i>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--            <h5 class="mb-3">Commitment to Quality:</h5>-->
                <!--            <p class="text-body mb-0">We adhere to strict quality control measures at every stage of production. Our vehicles are built using advanced technology and premium materials, ensuring durability, safety, and long-lasting performance.</p>-->
                <!--        </a>-->
                <!--    </div>-->
                <!--    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.3s">-->
                <!--        <a class="service-item rounded" href="">-->
                <!--            <div class="service-icon bg-transparent border rounded p-1">-->
                <!--                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">-->
                <!--                    <i class="fa fa-spa fa-2x text-primary"></i>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--            <h5 class="mb-3">Sustainable Solutions:</h5>-->
                <!--            <p class="text-body mb-0">Our electric vehicles promote sustainable mobility, reducing carbon emissions and supporting a greener environment. By choosing Saera Electric Auto, you contribute to a cleaner future with eco-friendly transportation.</p>-->
                <!--        </a>-->
                <!--    </div>-->
                <!--    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.4s">-->
                <!--        <a class="service-item rounded" href="">-->
                <!--            <div class="service-icon bg-transparent border rounded p-1">-->
                <!--                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">-->
                <!--                    <i class="fa fa-users fa-2x text-primary"></i>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--            <h5 class="mb-3">Customer-Centric Approach:</h5>-->
                <!--            <p class="text-body mb-0">We prioritize our customers' needs, offering customized solutions to fit specific requirements. Our dedicated customer service ensures timely deliveries and reliable after-sales support, building long-term relationships with our clients.</p>-->
                <!--        </a>-->
                <!--    </div>-->
                <!--    <div class="col-lg-4 col-md-6 wow fadeInUp" data-wow-delay="0.5s">-->
                <!--        <a class="service-item rounded" href="">-->
                <!--            <div class="service-icon bg-transparent border rounded p-1">-->
                <!--                <div class="w-100 h-100 border rounded d-flex align-items-center justify-content-center">-->
                <!--                    <i class="bi bi-person-badge-fill fa-2x text-primary"></i>-->
                <!--                </div>-->
                <!--            </div>-->
                <!--            <h5 class="mb-3">Experienced Industry Leader:</h5>-->
                <!--            <p class="text-body mb-0">With a strong reputation in the electric vehicle industry, we have established ourselves as a trusted name in the market. Our expertise in manufacturing, exporting, and supplying ensures you get the best products and services available.</p>-->
                <!--        </a>-->
                <!--    </div>-->
                <!--</div>-->
            </div>
        </div>
        <!-- Service End -->


        <!-- Testimonial Start 
        <div class="container-xxl testimonial my-5 py-5 bg-dark wow zoomIn" data-wow-delay="0.1s">
            <div class="container">
                <div class="owl-carousel testimonial-carousel py-5">
                    <div class="testimonial-item position-relative bg-white rounded overflow-hidden">
                        <p>Tempor stet labore dolor clita stet diam amet ipsum dolor duo ipsum rebum stet dolor amet diam stet. Est stet ea lorem amet est kasd kasd et erat magna eos</p>
                        <div class="d-flex align-items-center">
                            <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial-1.jpg" style="width: 45px; height: 45px;">
                            <div class="ps-3">
                                <h6 class="fw-bold mb-1">Client Name</h6>
                                <small>Profession</small>
                            </div>
                        </div>
                        <i class="fa fa-quote-right fa-3x text-primary position-absolute end-0 bottom-0 me-4 mb-n1"></i>
                    </div>
                    <div class="testimonial-item position-relative bg-white rounded overflow-hidden">
                        <p>Tempor stet labore dolor clita stet diam amet ipsum dolor duo ipsum rebum stet dolor amet diam stet. Est stet ea lorem amet est kasd kasd et erat magna eos</p>
                        <div class="d-flex align-items-center">
                            <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial-2.jpg" style="width: 45px; height: 45px;">
                            <div class="ps-3">
                                <h6 class="fw-bold mb-1">Client Name</h6>
                                <small>Profession</small>
                            </div>
                        </div>
                        <i class="fa fa-quote-right fa-3x text-primary position-absolute end-0 bottom-0 me-4 mb-n1"></i>
                    </div>
                    <div class="testimonial-item position-relative bg-white rounded overflow-hidden">
                        <p>Tempor stet labore dolor clita stet diam amet ipsum dolor duo ipsum rebum stet dolor amet diam stet. Est stet ea lorem amet est kasd kasd et erat magna eos</p>
                        <div class="d-flex align-items-center">
                            <img class="img-fluid flex-shrink-0 rounded" src="img/testimonial-3.jpg" style="width: 45px; height: 45px;">
                            <div class="ps-3">
                                <h6 class="fw-bold mb-1">Client Name</h6>
                                <small>Profession</small>
                            </div>
                        </div>
                        <i class="fa fa-quote-right fa-3x text-primary position-absolute end-0 bottom-0 me-4 mb-n1"></i>
                    </div>
                </div>
            </div>
        </div>
         Testimonial End -->


        <!-- Team Start 
        <div class="container-xxl py-5">
            <div class="container">
                <div class="text-center wow fadeInUp" data-wow-delay="0.1s">
                    <h6 class="section-title text-center text-primary text-uppercase">Our Team</h6>
                    <h1 class="mb-5">Explore Our <span class="text-primary text-uppercase">Staffs</span></h1>
                </div>
                <div class="row g-4">
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.1s">
                        <div class="rounded shadow overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team-1.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                                <h5 class="fw-bold mb-0">Full Name</h5>
                                <small>Designation</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.3s">
                        <div class="rounded shadow overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team-2.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                                <h5 class="fw-bold mb-0">Full Name</h5>
                                <small>Designation</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.5s">
                        <div class="rounded shadow overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team-3.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                                <h5 class="fw-bold mb-0">Full Name</h5>
                                <small>Designation</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 wow fadeInUp" data-wow-delay="0.7s">
                        <div class="rounded shadow overflow-hidden">
                            <div class="position-relative">
                                <img class="img-fluid" src="img/team-4.jpg" alt="">
                                <div class="position-absolute start-50 top-100 translate-middle d-flex align-items-center">
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-facebook-f"></i></a>
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-twitter"></i></a>
                                    <a class="btn btn-square btn-primary mx-1" href=""><i class="fab fa-instagram"></i></a>
                                </div>
                            </div>
                            <div class="text-center p-4 mt-3">
                                <h5 class="fw-bold mb-0">Full Name</h5>
                                <small>Designation</small>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
         Team End -->


     
        
<?php include('footer.php') ?>