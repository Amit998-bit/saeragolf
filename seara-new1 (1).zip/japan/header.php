<!DOCTYPE html>
<html lang="en">

<head>
<!-- Google tag (gtag.js) -->
<script async src="https://www.googletagmanager.com/gtag/js?id=AW-16718193691"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'AW-16718193691');
</script>
    <meta charset="utf-8">
   
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title> <?php echo isset($page_title) ? $page_title : 'Saera Electric Auto Limited is an Indian manufacturer and supplier of two-seater golf carts.'; ?> </title>

    <meta name="description" content="  <?php echo isset($description) ? $description : 'Learn about Saera Electric Auto Limited superior two-seater golf carts in India. Eco-friendly, long-lasting, and perfect for a variety of applications.'; ?>">
   
  <meta name="keywords" content="<?php echo isset($keyword) ? $keyword : 'Two Seater Golf Cart, Two seater golf cart manufacturer in India, Two seater golf cart supplier in India, Two seater golf cart exporter in India, Best manufacture of two seater of golf cart'; ?>">
  
    <meta name="author" content="Saera Electric Auto Limited">
    <meta name="publisher" content="Saera Electric Auto Limited">
    <meta name="robots" content="all">
    <link rel="canonical" href="<?php echo 'https://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; ?>" />
 
    <meta property="og:title" content="Saera Electric Auto Limited - Leading manufacturer and supplier of two-seater golf carts.">
    <meta property="og:description" content="Learn about Saera Electric Auto Limited superior two-seater golf carts in India. Eco-friendly, long-lasting, and perfect for a variety of applications.">
    <meta property="og:url" content="https://www.example.com/">
    <meta property="og:type" content="website">
 
    <meta property="og:site_name" content="Saera Electric Auto Limited">
    <!-- Favicon -->
    <link href="img/favicon.ico" rel="icon">

    <!-- Google Web Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Heebo:wght@400;500;600;700&family=Montserrat:wght@400;500;600;700&display=swap" rel="stylesheet">  

    <!-- Icon Font Stylesheet -->
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.10.0/css/all.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.4.1/font/bootstrap-icons.css" rel="stylesheet">

    <!-- Libraries Stylesheet -->
    <link href="../lib/animate/animate.min.css" rel="stylesheet">
    <link href="../lib/owlcarousel/assets/owl.carousel.min.css" rel="stylesheet">
    <link href="../lib/tempusdominus/css/tempusdominus-bootstrap-4.min.css" rel="stylesheet" />

    <!-- Customized Bootstrap Stylesheet -->
    <link href="../css/bootstrap.min.css" rel="stylesheet">

    <!-- Template Stylesheet -->
    <link href="../css/style.css" rel="stylesheet">
    <link href="../css/whatsp.css" rel="stylesheet">
</head>

<body>
    <div class="container-fluid  bg-white p-0">
        <!-- Spinner Start -->
        <div id="spinner" class="show bg-white position-fixed translate-middle w-100 vh-100 top-50 start-50 d-flex align-items-center justify-content-center">
            <div class="spinner-border text-primary" style="width: 3rem; height: 3rem;" role="status">
                <span class="sr-only">Loading...</span>
            </div>
        </div>
        <!-- Spinner End -->

        <!-- Header Start -->
        <div class="container-fluid bg-dark px-0">
            <div class="row gx-0">
                <div class="col-lg-3 bg-dark d-none d-lg-block">
                    <a href="../index.php" title="Home" class="navbar-brand w-100 h-100 m-0 p-0 d-flex flex-column align-items-center justify-content-center">
                        <img src="../img/logo.png" alt="Saera Electric Auto Limited" title="Saera Electric Auto Limited" width="30%">
                        <p class="m-0 text-primary text-uppercase"> Saera Electric Auto Limited</p>
                    </a>
                </div>
                <div class="col-lg-9">
                    <div class="row gx-0 bg-white d-none d-lg-flex">
                         <div class="col-lg-7 px-3 text-start">
                            <div class="h-100 d-inline-flex align-items-center py-2 me-4">
                                <i class="fa fa-envelope text-primary me-2"></i>
                                <p class="mb-0" style="font-size:12px"><a class="open-mail-popup" title="Mail">salesmarketing.golfcart@saeraindia.com</a></p>
                            </div>
                            <div class="h-100 d-inline-flex align-items-center py-2">
                                <i class="fa fa-phone-alt text-primary me-2"></i>
                                <!--<p class="mb-0" style="font-size:12px">+91-9810109848</p>&nbsp;,&nbsp;&nbsp;-->
                                <p class="mb-0" style="font-size:12px">+91-9659965952</p>
                            </div>
                        </div>
                        <div class="col-lg-5 px-5 text-end">
                            <div class="d-inline-flex align-items-center py-2">
                                <a class="me-3" title="Facebook" href="https://www.facebook.com/saeragolfcart/"><i class="fab fa-facebook-f"></i></a>
                                <a class="me-3" title="Twitter" href="https://x.com/SaeraGolfCart"><i class="fab fa-twitter"></i></a>
                                <a class="me-3" ttile="Linkedin" href="https://www.linkedin.com/company/saera-electric-auto-pvt-ltd/"><i class="fab fa-linkedin-in"></i></a>
                                <a class="me-3" title="Instagram" href="https://www.instagram.com/saeragolfcarts/"><i class="fab fa-instagram"></i></a>
                                <!--<a class="" href=""><i class="fab fa-youtube"></i></a>-->
                            </div>
                        </div>
                    </div>
                    <nav class="navbar navbar-expand-lg bg-dark navbar-dark p-3 p-lg-0">
                        <a href="../index.php" title="Home" class="navbar-brand d-block d-lg-none">
                            <img src="../img/logo.png" alt="Saera Electric Auto Limited" title="Saera Electric Auto Limited" width="10%">
                            <p class="m-0 text-primary text-uppercase">Saera Electric Auto Limited</p>
                        </a>
                        <button type="button" class="navbar-toggler" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
                            <span class="navbar-toggler-icon"></span>
                        </button>
                        <div class="collapse navbar-collapse justify-content-between" id="navbarCollapse">
                            <div class="navbar-nav mr-auto py-0">
                                <a href="../index.php" class="nav-item nav-link active" title="Home">Home</a>
                                <a href="../company-profile.php" class="nav-item nav-link" title="Company Profile">Company Profile</a>
                                <div class="nav-item dropdown">
                                    <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Our Products</a>
                                    <div class="dropdown-menu rounded-0 m-0">
                                        <a href="2-seater-golf-cart.php" class="dropdown-item" title="2 Seater Golf Cart">2 Seater Golf Cart</a>
                                        <a href="4-seater-golf-cart.php" class="dropdown-item" title="4 Seater Golf Cart">4 Seater Golf Cart</a>
                                        <a href="6-seater-golf-cart.php" class="dropdown-item" title="6 Seater Golf Cart">6 Seater Golf Cart</a>
                                        <a href="8-seater-golf-cart.php" class="dropdown-item" title="8 Seater Golf Cart">8 Seater Golf Cart</a>
                                        <a href="2-seater-utility-golf-cart.php" class="dropdown-item" title="2 Seater Utility Golf Cart">2 Seater Utility Golf Cart</a>
                                        <a href="4-seater-utility-golf-cart.php" class="dropdown-item" title="4 Seater Utility Golf Cart">4 Seater Utility Golf Cart</a>
                                        <!--<a href="mayuri-grand-e-rickshaw.php" class="dropdown-item" title="Mayuri Grand E-rickshaw">Mayuri Grand E-rickshaw</a>-->
                                        <!--<a href="mayuri-loader-e-rickshaw.php" class="dropdown-item" title="Mayuri Loader">Mayuri Loader</a>-->
                                        <!--<a href="mayuri-auto-rickshaw.php" class="dropdown-item" title="Mayuri Auto">Mayuri Auto</a>-->
                                        <!--<a href="mayuri-delivery-van.php" class="dropdown-item" title="Mayuri Delivery Van">Mayuri Delivery Van</a>-->
                                    </div>
                                </div>
                                <a href="../blogs.php" class="nav-item nav-link" title="Blogs">Blogs</a>
                                <a href="../contact.php" class="nav-item nav-link" title="Contact Us">Contact us</a>
                            </div>
                            <a class="open-mail-popup btn btn-primary rounded-0 py-4 px-md-5 d-none d-lg-block">Get Enquiry<i class="fa fa-arrow-right ms-3"></i></a>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Header End -->