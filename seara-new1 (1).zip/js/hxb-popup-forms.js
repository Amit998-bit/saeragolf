// Handle WhatsApp Popup

// document.getElementById('whatsapp-trigger').addEventListener('click', function (e) {
//     e.preventDefault();
//     document.getElementById('whatsapp-popup').style.display = 'flex';
// });

// document.getElementById('close-whatsapp').addEventListener('click', function () {
//     document.getElementById('whatsapp-popup').style.display = 'none';
// });

// document.getElementById('whatsappForm').addEventListener('submit', function (e) {
//     e.preventDefault();
//     var name = document.getElementById('whatsappName').value;
//     var mobile = document.getElementById('whatsappMobile').value;
//     var whatsappUrl = `https://api.whatsapp.com/send?phone=+919659965952&text=Hi, My name is ${name} and my mobile number is ${mobile}.`;
//     window.open(whatsappUrl, '_blank');
// });

// Handle Mail Popup
document.getElementById('mail-trigger').addEventListener('click', function (e) {
    e.preventDefault();
    document.getElementById('mail-popup').style.display = 'flex';
});

document.getElementById('close-mail').addEventListener('click', function () {
    document.getElementById('mail-popup').style.display = 'none';
});

// document.getElementById('mailForm').addEventListener('submit', function (e) {
//     e.preventDefault();
//     alert("Thank you for your message! We will get back to you shortly.");
//     document.getElementById('mail-popup').style.display = 'none';
// });
  
// Handle WhatsApp form submission
document.getElementById('whatsappForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    var formData = new FormData(this);

    fetch('../form-handler.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        if (result === 'success') {
            alert('WhatsApp form submitted successfully!');
            document.getElementById('whatsapp-popup').style.display = 'none';
        }
        else {
            alert('There was an error submitting the form.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});

// Handle Mail form submission
document.getElementById('mailForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    var formData = new FormData(this);

    fetch('../form-handler.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        if (result === 'success') {
            alert('Mail form submitted successfully!');
            document.getElementById('mail-popup').style.display = 'none';
        } else {
            alert('There was an error submitting the form.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
    });
});

// Handle Footer Mail Popup

    // Open the mail popup using class
    const mailPopupLinks = document.querySelectorAll('.open-mail-popup');
    mailPopupLinks.forEach(link => {
        link.onclick = function(e) {
            e.preventDefault(); // Prevent the default anchor click behavior
            document.getElementById('mail-popup').style.display = 'flex'; // Show the popup
        };
    });

    // Close the mail popup
    document.getElementById('close-mail').onclick = function() {
        document.getElementById('mail-popup').style.display = 'none'; // Hide the popup
    };

    // Close the popup when clicking outside of it
    window.onclick = function(event) {
        const popup = document.getElementById('mail-popup');
        if (event.target === popup) {
            popup.style.display = 'none'; // Hide the popup
        }
    };
    
    
    // Contact page form
    
    document.getElementById('contactPageForm').addEventListener('submit', function(event) {
    event.preventDefault(); // Prevent default form submission

    // Collect form data
    var formData = new FormData(this);

    // Send data to the PHP handler
    fetch('../form-handler.php', {
        method: 'POST',
        body: formData
    })
    .then(response => response.text())
    .then(result => {
        if (result === 'success') {
            alert('Your message has been sent successfully!');
        } else {
            alert('There was an error sending your message. Please try again later.');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('There was an error sending your message. Please try again later.');
    });
    });

