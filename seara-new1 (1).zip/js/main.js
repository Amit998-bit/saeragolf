(function ($) {
    "use strict";

    // Spinner
    var spinner = function () {
        setTimeout(function () {
            if ($('#spinner').length > 0) {
                $('#spinner').removeClass('show');
            }
        }, 1);
    };
    spinner();
    
    
    // Initiate the wowjs
    new WOW().init();
    
    
    // Dropdown on mouse hover
    const $dropdown = $(".dropdown");
    const $dropdownToggle = $(".dropdown-toggle");
    const $dropdownMenu = $(".dropdown-menu");
    const showClass = "show";
    
    $(window).on("load resize", function() {
        if (this.matchMedia("(min-width: 992px)").matches) {
            $dropdown.hover(
            function() {
                const $this = $(this);
                $this.addClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "true");
                $this.find($dropdownMenu).addClass(showClass);
            },
            function() {
                const $this = $(this);
                $this.removeClass(showClass);
                $this.find($dropdownToggle).attr("aria-expanded", "false");
                $this.find($dropdownMenu).removeClass(showClass);
            }
            );
        } else {
            $dropdown.off("mouseenter mouseleave");
        }
    });
    
    
    // Back to top button
    $(window).scroll(function () {
        if ($(this).scrollTop() > 300) {
            $('.back-to-top').fadeIn('slow');
        } else {
            $('.back-to-top').fadeOut('slow');
        }
    });
    $('.back-to-top').click(function () {
        $('html, body').animate({scrollTop: 0}, 1500, 'easeInOutExpo');
        return false;
    });


    // Facts counter
    $('[data-toggle="counter-up"]').counterUp({
        delay: 10,
        time: 2000
    });


    // Modal Video
    $(document).ready(function () {
        var $videoSrc;
        $('.btn-play').click(function () {
            $videoSrc = $(this).data("src");
        });
        console.log($videoSrc);

        $('#videoModal').on('shown.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc + "?autoplay=1&amp;modestbranding=1&amp;showinfo=0");
        })

        $('#videoModal').on('hide.bs.modal', function (e) {
            $("#video").attr('src', $videoSrc);
        })
    });


    // Testimonials carousel
    $(".testimonial-carousel").owlCarousel({
        autoplay: true,
        smartSpeed: 1000,
        margin: 25,
        dots: false,
        loop: true,
        nav : true,
        navText : [
            '<i class="bi bi-arrow-left"></i>',
            '<i class="bi bi-arrow-right"></i>'
        ],
        responsive: {
            0:{
                items:1
            },
            768:{
                items:2
            }
        }
    });
    
})(jQuery);

// let emailLink = document.getElementById('emailLink');
// let popupForm = document.getElementById('popupForm');
// let closeButton = document.querySelector('.close-btn');

// emailLink.addEventListener('click', function(event) {
//     event.preventDefault();
//     popupForm.style.display = 'flex';
// });

// closeButton.addEventListener('click', function() {
//     popupForm.style.display = 'none';
// });

// window.addEventListener('click', function(event) {
//     if (event.target === popupForm) {
//         popupForm.style.display = 'none';
//     }
// });


// let emailLiink = document.getElementById('emailLiink');
// let popuppForm = document.getElementById('popuppForm');
// let closeeButton = document.querySelector('.closee-btn');

// emailLiink.addEventListener('click', function(event) {
//     event.preventDefault();
//     popuppForm.style.display = 'flex';
// });

// closeeButton.addEventListener('click', function() {
//     popuppForm.style.display = 'none';
// });

// window.addEventListener('click', function(event) {
//     if (event.target === popuppForm) {
//         popuppForm.style.display = 'none';
//     }
// });


// let emailLiiink = document.getElementById('emailLiiink');
// let popupppForm = document.getElementById('popupppForm');
// let closeeeButton = document.querySelector('.closeee-btn');

// emailLiiink.addEventListener('click', function(event) {
//     event.preventDefault();
//     popupppForm.style.display = 'flex';
// });

// closeeeButton.addEventListener('click', function() {
//     popupppForm.style.display = 'none';
// });

// window.addEventListener('click', function(event) {
//     if (event.target === popupppForm) {
//         popupppForm.style.display = 'none';
//     }
// });



// let emailLiiiink = document.getElementById('emailLiiiink');
// let popuppppForm = document.getElementById('popuppppForm');
// let closeeeeButton = document.querySelector('.closeeee-btn');

// emailLiiiink.addEventListener('click', function(event) {
//     event.preventDefault();
//     popuppppForm.style.display = 'flex';
// });

// closeeeeButton.addEventListener('click', function() {
//     popuppppForm.style.display = 'none';
// });

// window.addEventListener('click', function(event) {
//     if (event.target === popuppppForm) {
//         popuppppForm.style.display = 'none';
//     }
// });
// let emailLiiiiink = document.getElementById('emailLiiiiink');
// let popupppppForm = document.getElementById('popupppppForm');
// let closeeeeeButton = document.querySelector('.closeeeee-btn');

// emailLiiiiink.addEventListener('click', function(event) {
//     event.preventDefault();
//     popupppppForm.style.display = 'flex';
// });

// closeeeeeButton.addEventListener('click', function() {
//     popupppppForm.style.display = 'none';
// });

// window.addEventListener('click', function(event) {
//     if (event.target === popupppppForm) {
//         popupppppForm.style.display = 'none';
//     }
// });


