<?php include('header.php') ?>
     


        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-1.jpg);" title="2 Seater Golf Cart Manufacturers in India" alt="2 Seater Golf Cart Manufacturers in India">
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Market Area</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Market Area</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
           <!-- Contact Start -->
        <section class="services-section" style="margin-top:50px;">
            <div class="bg bg-pattern-2"></div>
            <div class="container">
              <div class="sec-title">
                <div class="row">
                  <div class="col-lg-12">
                    <span class="sub-title"></span>
                    <h2 style="background-color:#0F172B" class="text-center text-white"> Market Area Locations </h2>
                     <h4 style="background-color:#0F172B" class="text-center text-white"> States </h4>
                  </div> 
                </div>
              </div>
              <div class="row">
                <div class="services-column col-lg-12 col-md-12 col-sm-12">
             
                  <div class="inner-column">
                    
                    <div class="row country">
                      <div class="service-block col-lg-3 col-md-3 col-sm-6">
                        <a href="andhra-pradesh/2-seater-golf-cart.php">
                        <div class="inner-box">
                          <div class="icon-box">
                          </div>
                          <h3 class="title">Andhra Pradesh
                        </h3>
                        </div>
                       </a>
                      </div>
                      <div class="service-block col-lg-3 col-md-3 col-sm-6">
                        <a href="arunachal-pradesh/2-seater-golf-cart.php">
                        <div class="inner-box">
                          <div class="icon-box">
                          </div>
                          <h3 class="title"> Arunachal Pradesh </h3>
                        </div>
                        </a>
                      </div>
    
                      <!-- Service Block -->
                      <div class="service-block col-lg-3 col-md-3 col-sm-6">
                        <a href="assam/2-seater-golf-cart.php">
                        <div class="inner-box">
                          <div class="icon-box">
                           
                          </div>
                          <h3 class="title">Assam </h3>
                        </div>
                        </a>
                      </div>
    
                      <!-- Service Block -->
                      <div class="service-block col-lg-3 col-md-3 col-sm-6">
                        <a href="bihar/2-seater-golf-cart.php">
                        <div class="inner-box">
                          <div class="icon-box">
                           
                          </div>
                          <h3 class="title">Bihar</h3>
                        </div>
                       </a>
                      </div> 
                      <div class="service-block col-lg-3 col-md-3 col-sm-6">
                        <a href="chattisgarh/2-seater-golf-cart.php">
                        <div class="inner-box">
                          <div class="icon-box">
                           
                          </div>
                          <h3 class="title">Chhattisgarh</h3>
                        </div>
                      </a>
                      </div>  
                      <!--<div class="service-block col-lg-3 col-md-3 col-sm-6">-->
                      <!--  <a href="#">-->
                      <!--  <div class="inner-box">-->
                      <!--    <div class="icon-box">-->
                           
                      <!--    </div>-->
                      <!--    <h3 class="title"></h3>-->
                      <!--  </div>-->
                      <!--</a>-->
                      <!--</div>-->
                   
                    </div><!----row close-country---->
                       <br><br>
    
                      <h4 style="background-color:#0F172B" class="text-center text-white"> Countries </h4>
                     
                  </div>
                </div>
              </div>
             <div class="row">
                <div class="services-column col-lg-12 col-md-12 col-sm-12">
             
                  <div class="inner-column">
                    
                    <div class="row country">
                      <div class="service-block col-lg-3 col-md-3 col-sm-6">
                        <a href="argentina/2-seater-golf-cart.php">
                        <div class="inner-box">
                          <div class="icon-box">
                          </div>
                          <h3 class="title">Argentina
                        </h3>
                        </div>
                       </a>
                      </div>
                      <div class="service-block col-lg-3 col-md-3 col-sm-6">
                        <a href="bolivia/2-seater-golf-cart.php">
                        <div class="inner-box">
                          <div class="icon-box">
                          </div>
                          <h3 class="title">Bolivia</h3>
                        </div>
                        </a>
                      </div>
    
                      <!-- Service Block -->
                      <div class="service-block col-lg-3 col-md-3 col-sm-6">
                        <a href="japan/2-seater-golf-cart.php">
                        <div class="inner-box">
                          <div class="icon-box">
                           
                          </div>
                          <h3 class="title">Japan </h3>
                        </div>
                        </a>
                      </div>
    
                      <!-- Service Block -->
                      <div class="service-block col-lg-3 col-md-3 col-sm-6">
                        <a href="mexico/2-seater-golf-cart.php">
                        <div class="inner-box">
                          <div class="icon-box">
                           
                          </div>
                          <h3 class="title">Mexico</h3>
                        </div>
                       </a>
                      </div> 
                      <div class="service-block col-lg-3 col-md-3 col-sm-6">
                        <a href="thailand/2-seater-golf-cart.php">
                        <div class="inner-box">
                          <div class="icon-box">
                           
                          </div>
                          <h3 class="title">Thailand</h3>
                        </div>
                      </a>
                      </div>  
                      <!--<div class="service-block col-lg-3 col-md-3 col-sm-6">-->
                      <!--  <a href="#">-->
                      <!--  <div class="inner-box">-->
                      <!--    <div class="icon-box">-->
                           
                      <!--    </div>-->
                      <!--    <h3 class="title"></h3>-->
                      <!--  </div>-->
                      <!--</a>-->
                      <!--</div>-->
                   
                    </div><!----row close-country---->
                   
                     
                  </div>
                </div>
              </div>
            </div>
          </section>
<?php include('footer.php') ?>