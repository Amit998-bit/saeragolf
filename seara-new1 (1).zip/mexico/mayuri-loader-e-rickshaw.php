<?php $page_title = " Mayuri Loader Manufacturer of Electric Cargo Vehicles in Mexico ";
  $description = " For industrial and logistical applications, Saera Electric Auto Limited offers robust Mayuri Loaders.";
  $keyword = "Mayuri Loader, Electric Loader Manufacturer in Mexico, Electric Loader Supplier in Mexico, Cargo Loader Mexico, EcoFriendly Logistics Vehicle Mexico, Industrial Electric Loader";
  include('header.php'); ?>
        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(../img/carousel-1.jpg);" title="Mayuri Loader e-rikshaw Manufacturers in Mexico" alt="Mayuri Loader e-rikshaw Manufacturers in Mexico">
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Mayuri Loader e-rikshaw</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Mayuri Loader e-rikshaw</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->

        <div class="container meta">
             

            <h2><strong> Mayuri Loader e-rikshaw Manufacturers in Mexico </strong> </h2>
            <p>A reputable producer of Mayuri loaders, Saera Electric Auto Limited provides sturdy and dependable electric loaders for a range of industrial uses. Our electric loaders are made to easily manage demanding jobs, offering a longterm solution for construction, material handling, and other heavy lifting requirements. These loaders are made to last and have a minimal environmental impact thanks to their strong motors and sturdy parts.</p>

            <h2><strong> Mayuri Loader e-rikshaw Suppliers in Mexico</strong></h2>
            <p>Saera Electric Auto Limited is a top supplier of Mayuri loaders in Mexico, providing highperformance and adaptable electric loaders. Industries that need effective material transportation in urban, industrial, and agricultural environments will find these electric vehicles suitable. Because of their great efficiency and ability to manoeuvre through tight locations, our loaders are ideal for use in factories, warehouses, and construction sites.</p>

            <h2><strong> Mayuri Loader e-rikshaw Exporters in Mexico </strong> </h2>
            <p>A wellknown supplier of Mayuri loaders, Saera Electric Auto Limited offers dependable and environmentally friendly loaders to customers in Mexico and other foreign markets. Our electric loaders are built to international standards, providing excellent performance and affordable heavylifting options. We guarantee that our global clients receive superior products and outstanding service since we are dedicated to sustainability and customer pleasure.</p>

 
        </div>
        <div class="container">
            <div class="product col-lg-12">
                <div class="product-image col-lg-6">
                    <img src="../img/mayuri-loader.png" alt="Mayuri Loader e-rikshaw Manufacturer in Mexico" title="Mayuri Loader e-rikshaw Manufacturer in Mexico">
                </div>
                <div class="product-des col-lg-6">
                    <h2>Mayuri Loader e-rikshaw</h2>
                    <p>The Mayuri Loader e-rikshaw is engineered specifically for efficient goods transportation within urban areas. This electric vehicle features a spacious loading area, enabling businesses to transport various types of cargo safely and effectively. The Mayuri Loader is designed to navigate narrow city streets easily, making it an excellent choice for logistics companies and local vendors. With zero emissions and minimal maintenance costs, this e-rikshaw supports eco-friendly practices in urban logistics. Its sturdy build ensures durability while maintaining high performance, allowing for reliable service that meets the demands of modern delivery solutions.</p>
                </div>
            </div>
        </div>
        <div class="container mt-4">
  
  <div class="d-flex flex-wrap align-items-center">
      <h4>Colours Available : </h4>
    <div style="width: 30px; height: 30px; background-color: red; margin-right: 5px; margin-left:5px;"></div>
    <div style="width: 30px; height: 30px; background-color: green; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: black; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: lightblue; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: blue; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: lightgray; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: gray; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: orange; margin-right: 5px;"></div>
    <div style="width: 30px; height: 30px; background-color: yellow; margin-right: 5px;"></div>
  </div>
</div>
<br>
        <div class="spec-container">
            <h4 class="text-center mb-4">Technical Specifications</h4>
            
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Motor Power:</p>
                        <p class="spec-description">1500-Watt</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Suspension:</p>
                        <p class="spec-description">Telescopic (F), Leaf Spring (R)</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Brakes:</p>
                        <p class="spec-description">Drum Brakes (Front & Rear)</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">L x W x H:</p>
                        <p class="spec-description">2690 mm x 1000 mm x 1710 mm</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Mileage:</p>
                        <p class="spec-description">Up to 120 Km / Charge*</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Bluetooth Music System:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Central Locking System:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Driver Mirror with Lights:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">LED Headlights with DRL:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Lockable Driver Glovebox:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Reverse Buzzer System:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Highest Durability Steel Rims:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Windshield with Motorized Wiper:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Rugged & Heavy-Duty Suspension:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">3 Side Opening Bed:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        
            <div class="spec-row">
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">Driver and Passenger Curtains:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
                <div class="spec-column">
                    <div class="spec-card">
                        <p class="spec-title">3 Side Opening Cargo Bed:</p>
                        <p class="spec-description">Yes</p>
                    </div>
                </div>
            </div>
        </div>
        
<?php include('footer.php') ?>