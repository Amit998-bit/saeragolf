<?php include('header.php') ?>
 
        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-1.jpg);">
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Return Policy</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Return Policy</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->


        

        <div class="container">
            <div class="company-overview">
               
                <p>At Saera Golf Cart, we strive to ensure that every product meets the highest standards of quality and performance. While we do not offer a return policy, we are committed to resolving any issues or faults with your golf cart as per the terms outlined in our warranty and service policies mentioned in the owner’s manual.</p>
                <p>If you experience any issues with your golf cart, please contact our customer support team or visit an authorized service center. Our dedicated team will ensure prompt assistance to address your concerns.</p>
                
                <p>For further details, refer to the owner’s manual or contact us directly. Thank you for choosing Saera Golf Cart!</p>
                
               
              
            </div>
        </div>


 <?php include('footer.php') ?>