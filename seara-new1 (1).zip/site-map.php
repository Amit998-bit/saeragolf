<?php include('header.php') ?>
 
        <!-- Page Header Start -->
        <div class="container-fluid page-header mb-5 p-0" style="background-image: url(img/carousel-1.jpg);">
            <div class="container-fluid page-header-inner py-5">
                <div class="container text-center pb-5">
                    <h1 class="display-3 text-white mb-3 animated slideInDown">Site Map</h1>
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb justify-content-center text-uppercase">
                            <li class="breadcrumb-item"><a href="index.html">Home</a></li>
                            <li class="breadcrumb-item text-white active" aria-current="page">Site Map</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>
        <!-- Page Header End -->


        

        <div class="container">
            <ul>
                <li><a href="index.php">Home</a></li>
                <li><a href="about-us.php">About Us</a></li>
                <li><a href="2-seater-golf-cart.php">2 Seater Golf Cart</a></li>
                 <li><a href="2-seater-utility-golf-cart.php">2 Seater Utility Golf Cart</a></li>
                  <li><a href="4-seater-golf-cart.php">4 Seater Golf Cart</a></li>
                   <li><a href="4-seater-utility-golf-cart.php">4 Seater Utility Golf Cart</a></li>
                    <li><a href="6-seater-golf-cart.php">6 Seater Golf Cart</a></li>
                    <li><a href="8-seater-golf-cart.php">8 Seater Golf Cart</a></li>
                    <li><a href="contact-us.php">Contact Us</a></li>
                    <li><a href="blog.php">Blogs</a></li>
                    <li><a href="market-area.php">Market Area</a></li>
            </ul>
        </div>


 <?php include('footer.php') ?>